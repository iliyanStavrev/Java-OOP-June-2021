package restaurant.entities.healthyFoods;

public class Salad extends Food{


    public Salad(String name, double price) {
        super(name, 150, price);
    }
}
