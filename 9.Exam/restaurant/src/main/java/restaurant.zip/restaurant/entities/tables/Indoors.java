package restaurant.entities.tables;

public class Indoors extends BaseTable{

    public Indoors(int number, int size) {
        super(number, size, 3.50);
    }
}
