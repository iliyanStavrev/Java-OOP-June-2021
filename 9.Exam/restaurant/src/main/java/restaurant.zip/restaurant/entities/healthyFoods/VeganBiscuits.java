package restaurant.entities.healthyFoods;

public class VeganBiscuits extends Food{

    public VeganBiscuits(String name, double price) {
        super(name, 205, price);
    }
}
