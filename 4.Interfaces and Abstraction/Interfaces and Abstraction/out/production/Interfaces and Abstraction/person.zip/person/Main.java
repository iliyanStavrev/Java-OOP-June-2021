package person;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String input = scanner.nextLine();
        List<Birthable>birthables = new ArrayList<>();
        while (!input.equals("End")){
            String[] tokens = input.split("\\s+");
            String variety = tokens[0];
          switch (variety){
              case "Citizen":
                  Citizen citizen = new Citizen(tokens[1],
                          Integer.parseInt(tokens[2]),tokens[3],tokens[4]);
                  birthables.add(citizen);
                  break;
              case "Pet":
                  Pet pet = new Pet(tokens[1],tokens[2]);
                  birthables.add(pet);
                  break;
              case "Robot":
                  break;
          }
            input = scanner.nextLine();
        }
       input = scanner.nextLine();
        for (Birthable birthable : birthables) {
            String year = birthable.getBirthDate().split("/")[2];
            if (year.equals(input)){
                System.out.println(birthable.getBirthDate());
            }
        }
    }
}
