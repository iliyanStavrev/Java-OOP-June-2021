package animals;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String input = scanner.nextLine();
        List<Animal>animals = new ArrayList<>();

        while (!input.equals("Beast!")){
            String[] secondLine = scanner.nextLine().split("\\s+");
            String name = secondLine[0];
            int age = Integer.parseInt(secondLine[1]);
            String gender = secondLine[2];

            try {
                Animal animal = null;
                switch (input) {
                    case "Dog":
                        animal = new Dog(name, age, gender);
                        break;
                    case "Cat":
                        animal = new Cat(name, age, gender);
                        break;
                    case "Frog":
                        animal = new Frog(name, age, gender);
                        break;
                    case "Kitten":
                        animal = new Kitten(name, age);
                        break;
                    case "Tomcat":
                        animal = new Tomcat(name, age);
                        break;
                }
                animals.add(animal);
            }catch (IllegalArgumentException ex){
                System.out.print(ex.getMessage());
            }

            input = scanner.nextLine();
        }
        for (Animal animal : animals) {
            System.out.println(animal.toString());
        }
    }
}
