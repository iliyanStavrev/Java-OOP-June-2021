public class Cat extends Animal{
    public void meowing(){
        System.out.println("meowing...");
    }
}
