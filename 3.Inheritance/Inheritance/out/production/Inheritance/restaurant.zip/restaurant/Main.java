package restaurant;

import java.math.BigDecimal;

public class Main {
    public static void main(String[] args) {

    }
}
