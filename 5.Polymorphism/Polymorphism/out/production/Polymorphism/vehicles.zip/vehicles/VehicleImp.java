package vehicles;

public interface VehicleImp {
    String drive(double distance);
    void refuel(double litters);
}
