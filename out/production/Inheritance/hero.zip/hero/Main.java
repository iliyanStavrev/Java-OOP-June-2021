package hero;

public class Main {
    public static void main(String[] args) {
         MuseElf elf = new MuseElf("Elf",13);
        System.out.println(elf.toString());
    }
}
