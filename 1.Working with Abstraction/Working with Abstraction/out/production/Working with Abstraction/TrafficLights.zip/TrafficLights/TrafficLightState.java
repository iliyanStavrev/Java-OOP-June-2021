package TrafficLights;

public enum TrafficLightState {
    GREEN,
    RED,
    YELLOW;
}
